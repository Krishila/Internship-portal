const jwt = require('jsonwebtoken');

// Verify Token
exports.verifyToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ message: 'Access Denied: No Token Provided' });
    }

    try {
        const verified = jwt.verify(token, process.env.JWT_SECRET || 'secretkey');
        req.user = verified;
        next();
    } catch (err) {
        res.status(403).json({ message: 'Invalid or Expired Token' });
    }
};

exports.checkRole = (allowedRoles) => {
    return (req, res, next) => {
        const userRole = req.user.role ? req.user.role.toLowerCase() : '';
        const lowerAllowedRoles = allowedRoles.map(r => r.toLowerCase());

        if (!lowerAllowedRoles.includes(userRole) && !allowedRoles.includes(req.user.role_id)) {
            return res.status(403).json({ message: 'Access Denied: Unauthorized Role' });
        }
        next();
    };
};