const db = require('../config/db');

const Internship = {

    // Get approved internships
    getApproved: () => {
        return new Promise((resolve, reject) => {

            const query = `
                SELECT *
                FROM internships
                WHERE is_approved = 1
                AND (deadline >= CURDATE() OR deadline IS NULL)
                ORDER BY id DESC
            `;

            db.query(query, (err, results) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(results);
                }
            });
        });
    },


    // Create internship
    create: (data) => {
        return new Promise((resolve, reject) => {

            const {
                title,
                company,
                location,
                stipend,
                description,
                deadline,
                posted_by
            } = data;

            const query = `
                INSERT INTO internships
                (
                    title,
                    company,
                    location,
                    description,
                    stipend,
                    deadline,
                    posted_by,
                    is_approved,
                    verification_status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, 0, 'Pending')
            `;

            db.query(
                query,
                [
                    title,
                    company,
                    location,
                    description,
                    stipend || null,
                    deadline || null,
                    posted_by
                ],
                (err, result) => {

                    if (err) {
                        reject(err);
                    } else {
                        resolve(result.insertId);
                    }
                }
            );
        });
    }

};

module.exports = Internship;