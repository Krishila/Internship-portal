const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

exports.register = async (req, res) => {
    try {
        const name = req.body.name || req.body.full_name;
        const { email, password, role } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({ message: 'Please provide all required fields.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const userRole = role ? role.toLowerCase() : 'student';
        const query = 'INSERT INTO users (name, email, password_hash, role, status) VALUES (?, ?, ?, ?, ?)';

        db.query(query, [name, email, hashedPassword, userRole, 'ACTIVE'], (err, result) => {
            if (err) {
                console.error('Registration DB Error:', err);
                return res.status(500).json({ message: 'Database error: ' + err.message });
            }
            return res.status(201).json({ message: 'User registered successfully!' });
        });
    } catch (error) {
        console.error('Registration Catch Error:', error);
        return res.status(500).json({ message: 'Server error: ' + error.message });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ message: 'Please provide both email and password.' });
        }

        const query = 'SELECT id, name, email, password_hash, role FROM users WHERE email = ?';

        db.query(query, [email], async (err, results) => {
            if (err) {
                console.error('Login DB Error:', err);
                return res.status(500).json({ error: err.message });
            }

            if (!results || results.length === 0) {
                return res.status(401).json({ message: 'Invalid email or password.' });
            }

            const user = results[0];
            const isMatch = await bcrypt.compare(password, user.password_hash);

            if (!isMatch) {
                return res.status(401).json({ message: 'Invalid email or password.' });
            }

            const token = jwt.sign(
                { id: user.id, role: user.role },
                process.env.JWT_SECRET || 'YOUR_SECRET_KEY',
                { expiresIn: '1d' }
            );

            return res.json({
                token,
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    role: user.role
                }
            });
        });
    } catch (error) {
        console.error('Login Catch Error:', error);
        return res.status(500).json({ error: error.message });
    }
};