const db = require('../config/db');

exports.getAllInternships = (req, res) => {
    const query = 'SELECT * FROM internships WHERE deadline >= CURDATE() OR deadline IS NULL';
    db.query(query, (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error: ' + err.message });
        }
        res.json(rows);
    });
};

exports.createInternship = (req, res) => {
    let { title, company, location, description, stipend, deadline } = req.body;
    const userId = req.user ? req.user.id : null;

    if (!deadline || (typeof deadline === 'string' && deadline.trim() === '')) {
        deadline = null;
    }

    const query = 'INSERT INTO internships (title, company, location, description, stipend, deadline, posted_by) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(query, [title, company, location, description, stipend, deadline, userId], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Database error: ' + err.message });
        }
        res.status(201).json({ message: 'Internship posted successfully!' });
    });
};