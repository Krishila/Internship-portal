const db = require('../config/db');


// ======================================================
// 1. APPLY TO INTERNSHIP
// ======================================================

const applyToInternship = (req, res) => {

    const {
        internship_id,
        full_name,
        address,
        phone,
        resume_link
    } = req.body;

    const studentId = req.user.id;


    // ------------------------------------------
    // Validate required fields
    // ------------------------------------------

    if (
        !internship_id ||
        !full_name ||
        !address ||
        !phone ||
        !resume_link
    ) {
        return res.status(400).json({
            message:
                'All fields (Name, Address, Phone, Resume Link) are required.'
        });
    }


    // ------------------------------------------
    // Check internship
    // ------------------------------------------

    const checkInternshipSql = `
        SELECT
            id,
            title,
            deadline,
            posted_by
        FROM internships
        WHERE id = ?
    `;


    db.query(
        checkInternshipSql,
        [internship_id],
        (err, results) => {

            if (err) {
                console.error(
                    'MySQL Internship Check Error:',
                    err
                );

                return res.status(500).json({
                    message:
                        'Database error while checking internship.'
                });
            }


            if (results.length === 0) {
                return res.status(404).json({
                    message:
                        'Internship not found.'
                });
            }


            const internship = results[0];


            // ------------------------------------------
            // Check deadline
            // ------------------------------------------

            if (internship.deadline) {

                const deadline =
                    new Date(internship.deadline);

                if (new Date() > deadline) {

                    return res.status(400).json({
                        message:
                            'Application deadline has passed.'
                    });
                }
            }


            // ------------------------------------------
            // Check duplicate application
            // ------------------------------------------

            const duplicateSql = `
                SELECT id
                FROM applications
                WHERE internship_id = ?
                AND student_id = ?
            `;


            db.query(
                duplicateSql,
                [
                    internship_id,
                    studentId
                ],
                (duplicateErr, existing) => {

                    if (duplicateErr) {

                        console.error(
                            'MySQL Duplicate Check Error:',
                            duplicateErr
                        );

                        return res.status(500).json({
                            message:
                                'Database error: ' +
                                duplicateErr.message
                        });
                    }


                    if (existing.length > 0) {

                        return res.status(400).json({
                            message:
                                'You have already applied for this internship.'
                        });
                    }


                    // ------------------------------------------
                    // Insert application
                    // ------------------------------------------

                    const insertSql = `
                        INSERT INTO applications
                        (
                            internship_id,
                            student_id,
                            full_name,
                            address,
                            phone,
                            resume_link,
                            status,
                            applied_at
                        )
                        VALUES
                        (
                            ?,
                            ?,
                            ?,
                            ?,
                            ?,
                            ?,
                            'Submitted',
                            NOW()
                        )
                    `;


                    db.query(
                        insertSql,
                        [
                            internship_id,
                            studentId,
                            full_name,
                            address,
                            phone,
                            resume_link
                        ],
                        (insertErr, result) => {

                            if (insertErr) {

                                console.error(
                                    'MySQL Application Insert Error:',
                                    insertErr
                                );

                                return res.status(500).json({
                                    message:
                                        'Database error: ' +
                                        insertErr.message
                                });
                            }


                            const applicationId =
                                result.insertId;


                            // ------------------------------------------
                            // Create initial status history
                            // ------------------------------------------

                            const historySql = `
                                INSERT INTO application_status_history
                                (
                                    application_id,
                                    old_status,
                                    new_status,
                                    changed_by
                                )
                                VALUES (?, ?, ?, ?)
                            `;


                            db.query(
                                historySql,
                                [
                                    applicationId,
                                    null,
                                    'Submitted',
                                    studentId
                                ],
                                (historyErr) => {

                                    if (historyErr) {

                                        console.error(
                                            'Initial Status History Error:',
                                            historyErr
                                        );
                                    }


                                    // ------------------------------------------
                                    // Notify employer
                                    // ------------------------------------------

                                    const notificationSql = `
                                        INSERT INTO notifications
                                        (
                                            user_id,
                                            title,
                                            message
                                        )
                                        VALUES (?, ?, ?)
                                    `;


                                    const notificationMessage =
                                        `A new application has been submitted ` +
                                        `for "${internship.title}".`;


                                    db.query(
                                        notificationSql,
                                        [
                                            internship.posted_by,
                                            'New Application',
                                            notificationMessage
                                        ],
                                        (notificationErr) => {

                                            if (notificationErr) {

                                                console.error(
                                                    'Employer Notification Error:',
                                                    notificationErr
                                                );
                                            }


                                            return res.status(201).json({
                                                message:
                                                    'Application submitted successfully!',

                                                application_id:
                                                    applicationId
                                            });
                                        }
                                    );
                                }
                            );
                        }
                    );
                }
            );
        }
    );
};



// ======================================================
// 2. GET STUDENT APPLICATIONS
// ======================================================

const getStudentApplications = (req, res) => {

    const studentId = req.user.id;


    const sql = `
        SELECT
            a.id,
            a.status,
            a.applied_at AS applied_date,

            i.title AS internship_title,
            i.location,
            i.stipend,

            COALESCE(
                NULLIF(i.company, ''),
                'Internal Portal'
            ) AS company_name

        FROM applications a

        INNER JOIN internships i
            ON a.internship_id = i.id

        WHERE a.student_id = ?

        ORDER BY a.applied_at DESC
    `;


    db.query(
        sql,
        [studentId],
        (err, results) => {

            if (err) {

                console.error(
                    'Get Student Applications Error:',
                    err
                );

                return res.status(500).json({
                    message:
                        'Failed to load applications'
                });
            }


            return res.json(results);
        }
    );
};



// ======================================================
// 3. GET APPLICATION STATUS HISTORY
// ======================================================

const getApplicationStatusHistory = (req, res) => {

    const applicationId =
        req.params.id;

    const studentId =
        req.user.id;


    const sql = `
        SELECT
            h.id,
            h.old_status,
            h.new_status,
            h.changed_at

        FROM application_status_history h

        INNER JOIN applications a
            ON h.application_id = a.id

        WHERE
            h.application_id = ?
            AND a.student_id = ?

        ORDER BY h.changed_at ASC
    `;


    db.query(
        sql,
        [
            applicationId,
            studentId
        ],
        (err, results) => {

            if (err) {

                console.error(
                    'Status History Error:',
                    err
                );

                return res.status(500).json({
                    message:
                        'Failed to load application history'
                });
            }


            return res.json(results);
        }
    );
};



// ======================================================
// 4. UPDATE APPLICATION STATUS
// ======================================================

const updateApplicationStatus = (req, res) => {

    const { id } = req.params;

    const { status } = req.body;

    const userId = req.user.id;

    const userRole = req.user.role
        ? req.user.role.toLowerCase()
        : '';


    // ------------------------------------------
    // Allowed statuses
    // ------------------------------------------

    const allowedStatuses = [
        'Submitted',
        'Pending',
        'Shortlisted',
        'Interviewing',
        'Accepted',
        'Rejected'
    ];


    if (!allowedStatuses.includes(status)) {

        return res.status(400).json({
            message:
                'Invalid application status'
        });
    }


    // ------------------------------------------
    // Get application
    // ------------------------------------------

    const getApplicationSql = `
        SELECT
            a.id,
            a.status AS old_status,
            a.student_id,
            a.internship_id,

            i.posted_by,
            i.title AS internship_title

        FROM applications a

        INNER JOIN internships i
            ON a.internship_id = i.id

        WHERE a.id = ?
    `;


    db.query(
        getApplicationSql,
        [id],
        (err, results) => {

            if (err) {

                console.error(
                    'Get Application Error:',
                    err
                );

                return res.status(500).json({
                    message:
                        'Database error'
                });
            }


            if (results.length === 0) {

                return res.status(404).json({
                    message:
                        'Application not found'
                });
            }


            const application =
                results[0];


            // ------------------------------------------
            // Authorization
            // ------------------------------------------

            const isAdmin =
                userRole === 'admin';


            const isEmployerOwner =
                userRole === 'employer' &&
                Number(application.posted_by) ===
                Number(userId);


            if (
                !isAdmin &&
                !isEmployerOwner
            ) {

                return res.status(403).json({
                    message:
                        'You are not authorized to update this application'
                });
            }


            // ------------------------------------------
            // Prevent duplicate status
            // ------------------------------------------

            if (
                application.old_status ===
                status
            ) {

                return res.status(400).json({
                    message:
                        `Application is already ${status}`
                });
            }


            // ------------------------------------------
            // Update application
            // ------------------------------------------

            const updateSql = `
                UPDATE applications
                SET status = ?
                WHERE id = ?
            `;


            db.query(
                updateSql,
                [
                    status,
                    id
                ],
                (updateErr) => {

                    if (updateErr) {

                        console.error(
                            'Update Application Error:',
                            updateErr
                        );

                        return res.status(500).json({
                            message:
                                'Failed to update application status'
                        });
                    }


                    // ------------------------------------------
                    // Save status history
                    // ------------------------------------------

                    const historySql = `
                        INSERT INTO application_status_history
                        (
                            application_id,
                            old_status,
                            new_status,
                            changed_by
                        )
                        VALUES (?, ?, ?, ?)
                    `;


                    db.query(
                        historySql,
                        [
                            id,
                            application.old_status,
                            status,
                            userId
                        ],
                        (historyErr) => {

                            if (historyErr) {

                                console.error(
                                    'Status History Error:',
                                    historyErr
                                );
                            }


                            // ------------------------------------------
                            // Notify student
                            // ------------------------------------------

                            const notificationSql = `
                                INSERT INTO notifications
                                (
                                    user_id,
                                    title,
                                    message
                                )
                                VALUES (?, ?, ?)
                            `;


                            const notificationMessage =
                                `Your application for ` +
                                `"${application.internship_title}" ` +
                                `has been changed from ` +
                                `${application.old_status} ` +
                                `to ${status}.`;


                            db.query(
                                notificationSql,
                                [
                                    application.student_id,
                                    'Application Status Updated',
                                    notificationMessage
                                ],
                                (notificationErr) => {

                                    if (notificationErr) {

                                        console.error(
                                            'Notification Error:',
                                            notificationErr
                                        );
                                    }


                                    return res.json({

                                        message:
                                            'Application status updated successfully',

                                        old_status:
                                            application.old_status,

                                        new_status:
                                            status
                                    });
                                }
                            );
                        }
                    );
                }
            );
        }
    );
};



// ======================================================
// 5. GET ALL APPLICATIONS
// ======================================================

// Admin -> all applications
// Employer -> own internship applications
const getAllApplications = (req, res) => {

    const userId = req.user.id;

    const userRole = req.user.role
        ? req.user.role.toLowerCase()
        : '';


    let query = `
        SELECT

            a.id AS app_id,

            COALESCE(
                NULLIF(a.full_name, ''),
                u.name,
                'Candidate'
            ) AS student_name,

            COALESCE(
                a.address,
                ''
            ) AS address,

            COALESCE(
                NULLIF(a.phone, ''),
                'N/A'
            ) AS student_phone,

            COALESCE(
                NULLIF(a.resume_link, ''),
                ''
            ) AS student_resume,

            u.email AS student_email,

            i.title AS internship_title,

            COALESCE(
                NULLIF(i.company, ''),
                'Internal Portal'
            ) AS company,

            a.applied_at AS applied_date,

            a.status

        FROM applications a

        LEFT JOIN internships i
            ON a.internship_id = i.id

        LEFT JOIN users u
            ON a.student_id = u.id
    `;


    let queryParams = [];


    // ------------------------------------------
    // Employer
    // ------------------------------------------

    if (userRole === 'employer') {

        query += `
            WHERE i.posted_by = ?
        `;

        queryParams = [
            userId
        ];
    }


    // ------------------------------------------
    // Student
    // ------------------------------------------

    else if (userRole === 'student') {

        query += `
            WHERE a.student_id = ?
        `;

        queryParams = [
            userId
        ];
    }


    // ------------------------------------------
    // Admin
    // ------------------------------------------

    query += `
        ORDER BY a.applied_at DESC
    `;


    db.query(
        query,
        queryParams,
        (err, results) => {

            if (err) {

                console.error(
                    'Get All Applications Error:',
                    err
                );

                return res.status(500).json({
                    message:
                        'Database error',
                    error:
                        err.message
                });
            }


            return res.json(results);
        }
    );
};



// ======================================================
// 6. GET APPLICATIONS BY INTERNSHIP
// ======================================================

// Admin -> can see any internship applicants
// Employer -> can only see applicants for own internship
const getApplicationsByInternship = (
    req,
    res
) => {

    const internshipId =
        req.params.internshipId;

    const userId =
        req.user.id;

    const userRole =
        req.user.role
            ? req.user.role.toLowerCase()
            : '';


    // ------------------------------------------
    // First check internship ownership
    // ------------------------------------------

    const ownershipSql = `
        SELECT
            id,
            title,
            posted_by
        FROM internships
        WHERE id = ?
    `;


    db.query(
        ownershipSql,
        [internshipId],
        (ownershipErr, internshipResults) => {

            if (ownershipErr) {

                console.error(
                    'Internship Ownership Error:',
                    ownershipErr
                );

                return res.status(500).json({
                    message:
                        'Database error'
                });
            }


            if (internshipResults.length === 0) {

                return res.status(404).json({
                    message:
                        'Internship not found'
                });
            }


            const internship =
                internshipResults[0];


            // ------------------------------------------
            // Authorization
            // ------------------------------------------

            const isAdmin =
                userRole === 'admin';


            const isEmployerOwner =
                userRole === 'employer' &&
                Number(internship.posted_by) ===
                Number(userId);


            if (
                !isAdmin &&
                !isEmployerOwner
            ) {

                return res.status(403).json({
                    message:
                        'You are not authorized to view these applications'
                });
            }


            // ------------------------------------------
            // Get applicants
            // ------------------------------------------

            const query = `
                SELECT

                    a.id AS app_id,

                    COALESCE(
                        NULLIF(a.full_name, ''),
                        u.name,
                        'Candidate'
                    ) AS student_name,

                    COALESCE(
                        a.address,
                        ''
                    ) AS address,

                    COALESCE(
                        NULLIF(a.phone, ''),
                        'N/A'
                    ) AS student_phone,

                    COALESCE(
                        NULLIF(a.resume_link, ''),
                        ''
                    ) AS student_resume,

                    u.email AS student_email,

                    i.title AS internship_title,

                    COALESCE(
                        NULLIF(i.company, ''),
                        'Internal Portal'
                    ) AS company,

                    a.applied_at AS applied_date,

                    a.status

                FROM applications a

                LEFT JOIN internships i
                    ON a.internship_id = i.id

                LEFT JOIN users u
                    ON a.student_id = u.id

                WHERE a.internship_id = ?

                ORDER BY a.applied_at DESC
            `;

            db.query(
                query,
                [internshipId],
                (err, results) => {

                    if (err) {

                        console.error(
                            'Get Internship Applications Error:',
                            err
                        );

                        return res.status(500).json({
                            message:
                                'Database error',
                            error:
                                err.message
                        });
                    }


                    return res.json(results);
                }
            );
        }
    );
};

// ======================================================
// EXPORT CONTROLLERS
// ======================================================

// ======================================================
// EXPORT CONTROLLERS
// ======================================================
module.exports = {
    applyToInternship,
    getStudentApplications,
    getApplicationStatusHistory,
    updateApplicationStatus,
    getAllApplications,
    getApplicationsByInternship
};