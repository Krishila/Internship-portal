const express = require('express');
const router = express.Router();
const Internship = require('../models/Internship');

// 1. GET ALL APPROVED INTERNSHIPS (For Students)
router.get('/', async (req, res) => {
  try {
    const internships = await Internship.find({ isApproved: true });
    res.json(internships);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching internships', error: err.message });
  }
});

// 2. GET PENDING INTERNSHIPS (For Admins to Review)
router.get('/pending', async (req, res) => {
  try {
    const pendingInternships = await Internship.find({ isApproved: false });
    res.json(pendingInternships);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching pending internships', error: err.message });
  }
});

// 3. POST A NEW INTERNSHIP (For Employers)
router.post('/', async (req, res) => {
  try {
    const { title, company, location, stipend, description, deadline } = req.body;

    const newInternship = new Internship({
      title,
      company,
      location,
      stipend,
      description,
      deadline,
      isApproved: false // Requires admin approval before going live
    });

    await newInternship.save();
    res.status(201).json({ message: 'Internship submitted for admin review.', internship: newInternship });
  } catch (err) {
    res.status(400).json({ message: 'Failed to create internship', error: err.message });
  }
});

// 4. APPROVE AN INTERNSHIP (For Admins)
router.put('/approve/:id', async (req, res) => {
  try {
    const updatedInternship = await Internship.findByIdAndUpdate(
      req.params.id, 
      { isApproved: true }, 
      { new: true }
    );
    
    if (!updatedInternship) {
      return res.status(404).json({ message: 'Internship not found' });
    }

    res.json({ message: 'Internship approved successfully!', internship: updatedInternship });
  } catch (err) {
    res.status(500).json({ message: 'Error approving internship', error: err.message });
  }
});

module.exports = router;