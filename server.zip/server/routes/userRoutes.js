const express = require('express');
const router = express.Router();
const { verifyToken, checkRole } = require('../middleware/authMiddleware');
const db = require('../config/db');

// Accessible by any logged-in user
router.get('/profile', verifyToken, (req, res) => {
  res.json({ message: 'Profile data retrieved successfully', user: req.user });
});

// Accessible ONLY by admins
router.get('/admin-panel', verifyToken, checkRole(['admin']), (req, res) => {
  res.json({ message: 'Welcome to the admin panel' });
});

// Fetch notifications for the logged-in user
router.get('/notifications', verifyToken, (req, res) => {
    const userId = req.user?.id || req.user?.userId; 
    
    if (!userId) {
        return res.status(400).json({ message: 'User ID missing from token' });
    }

    db.query(
        'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC',
        [userId],
        (err, notifications) => {
            if (err) {
                console.error("Error fetching notifications:", err);
                return res.status(500).json({ message: 'Server error' });
            }
            res.json(notifications || []);
        }
    );
});

module.exports = router;