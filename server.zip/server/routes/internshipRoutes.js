const express = require('express');
const router = express.Router();

const Internship = require('../models/Internship');

const {
    verifyToken,
    checkRole
} = require('../middleware/authMiddleware');


// ==========================================
// GET APPROVED INTERNSHIPS
// ==========================================

router.get('/', verifyToken, async (req, res) => {

    try {

        const internships = await Internship.getApproved();

        res.json(internships);

    } catch (err) {

        console.error('Get internships error:', err);

        res.status(500).json({
            message: 'Error fetching internships',
            error: err.message
        });
    }
});


// ==========================================
// CREATE INTERNSHIP
// Employer / Admin only
// ==========================================

router.post(
    '/',
    verifyToken,
    checkRole(['employer', 'admin']),
    async (req, res) => {

        try {

            const {
                title,
                company,
                location,
                stipend,
                description,
                deadline
            } = req.body;


            // Required fields
            if (!title || !company || !location || !description) {

                return res.status(400).json({
                    message: 'Title, company, location and description are required.'
                });
            }


            // Create internship
            const newId = await Internship.create({

                title,
                company,
                location,
                description,
                stipend,
                deadline,

                // Logged-in employer/admin
                posted_by: req.user.id
            });


            res.status(201).json({

                message:
                    'Internship submitted for admin review.',

                internshipId: newId
            });


        } catch (err) {

            console.error('Create internship error:', err);

            res.status(500).json({

                message: 'Failed to create internship',

                error: err.message
            });
        }
    }
);


module.exports = router;