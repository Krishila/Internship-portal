const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifyToken, checkRole } = require('../middleware/authMiddleware');

// Get unapproved/pending internships and employers (Protected for admins)
router.get('/pending', verifyToken, checkRole(['admin']), (req, res) => {
    const internshipsQuery = `SELECT * FROM internships WHERE verification_status = 'Pending' OR is_approved = 0`;
    const employersQuery = `SELECT * FROM employers WHERE verification_status = 'Pending'`;

    db.query(internshipsQuery, (err, pendingInternships) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching pending internships: ' + err.message });
        }

        const formattedInternships = (pendingInternships || []).map(item => ({
            ...item,
            _id: item.id
        }));

        db.query(employersQuery, (err, pendingEmployers) => {
            if (err) {
                return res.status(500).json({ message: 'Error fetching pending employers: ' + err.message });
            }

            const formattedEmployers = (pendingEmployers || []).map(item => ({
                ...item,
                _id: item.id
            }));

            res.json({
                internships: formattedInternships,
                employers: formattedEmployers
            });
        });
    });
});

// Get all users (Protected for admins)
router.get('/users', verifyToken, checkRole(['admin']), (req, res) => {
    const query = 'SELECT id, name, email, role FROM users';
    db.query(query, (err, users) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching users: ' + err.message });
        }
        const formattedUsers = (users || []).map(user => ({
            ...user,
            _id: user.id
        }));
        res.json(formattedUsers);
    });
});

// Get all employers (Protected for admins)
router.get('/employers', verifyToken, checkRole(['admin']), (req, res) => {
    const query = 'SELECT * FROM employers';
    db.query(query, (err, employers) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching employers: ' + err.message });
        }
        const formattedEmployers = (employers || []).map(emp => ({
            ...emp,
            _id: emp.id
        }));
        res.json(formattedEmployers);
    });
});

// Verify/Approve an Internship (Protected for admins)
router.put('/internships/:id/verify', verifyToken, checkRole(['admin']), (req, res) => {
    const { id } = req.params;
    const { status } = req.body; 
    const approvalValue = status === 'Verified' ? 1 : 0;

    db.query('SELECT posted_by, title FROM internships WHERE id = ?', [id], (err, rows) => {
        const postedBy = rows && rows.length > 0 ? rows[0].posted_by : null;
        const jobTitle = rows && rows.length > 0 ? rows[0].title : 'Internship';

        db.query('UPDATE internships SET verification_status = ?, is_approved = ? WHERE id = ?', [status || 'Verified', approvalValue, id], (err) => {
            if (err) {
                return res.status(400).json({ message: 'Failed to update internship: ' + err.message });
            }

            if (postedBy) {
                db.query(
                    'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
                    [postedBy, 'Internship Status Updated', `Your internship listing "${jobTitle}" has been ${status ? status.toLowerCase() : 'verified'}.`]
                );
            }

            res.json({ message: 'Internship status updated successfully' });
        });
    });
});

// Verify/Approve an Employer (Protected for admins)
router.put('/employers/:id/verify', verifyToken, checkRole(['admin']), (req, res) => {
    const { id } = req.params;
    const { status } = req.body; 

    db.query('UPDATE employers SET verification_status = ? WHERE id = ?', [status || 'Verified', id], (err) => {
        if (err) {
            return res.status(400).json({ message: 'Failed to update employer: ' + err.message });
        }

        db.query(
            'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
            [id, 'Account Verification', `Your employer account has been ${status ? status.toLowerCase() : 'verified'}.`]
        );

        res.json({ message: 'Employer status updated successfully' });
    });
});

module.exports = router;