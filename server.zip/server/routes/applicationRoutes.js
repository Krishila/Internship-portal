const express = require('express');
const router = express.Router();

const {
    applyToInternship,
    getStudentApplications,
    getApplicationStatusHistory,
    updateApplicationStatus,
    getAllApplications,
    getApplicationsByInternship
} = require('../controllers/applicationController');

const {
    verifyToken,
    checkRole
} = require('../middleware/authMiddleware');

// Student Routes
router.post(
    '/apply',
    verifyToken,
    checkRole(['student']),
    applyToInternship
);

router.get(
    '/my-applications',
    verifyToken,
    checkRole(['student']),
    getStudentApplications
);

router.get(
    '/:id/history',
    verifyToken,
    checkRole(['student']),
    getApplicationStatusHistory
);

// Employer / Admin Routes
router.put(
    '/:id/status',
    verifyToken,
    checkRole(['employer', 'admin']),
    updateApplicationStatus
);

router.get(
    '/',
    verifyToken,
    checkRole(['admin', 'employer']),
    getAllApplications
);

router.get(
    '/all',
    verifyToken,
    checkRole(['admin', 'employer']),
    getAllApplications
);

router.get(
    '/:internshipId',
    verifyToken,
    checkRole(['admin', 'employer']),
    getApplicationsByInternship
);

module.exports = router;