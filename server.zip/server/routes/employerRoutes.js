const express = require('express');
const router = express.Router();

const db = require('../config/db');
const {
    verifyToken,
    checkRole
} = require('../middleware/authMiddleware');

// ==========================================
// GET EMPLOYER APPLICATIONS
// ==========================================
router.get(
    '/applications',
    verifyToken,
    checkRole(['employer', 'admin']),
    (req, res) => {
        const employerId = req.user.id;

        const query = `
            SELECT 
                a.id AS app_id,
                COALESCE(NULLIF(a.full_name, ''), 'Candidate') AS student_name,
                u.email AS student_email,
                COALESCE(a.phone, 'N/A') AS student_phone,
                COALESCE(a.resume_link, '') AS student_resume,
                COALESCE(a.address, '') AS address,
                IFNULL(i.title, 'General Application') AS internship_title,
                'Internal Portal' AS company,
                a.applied_at AS applied_date,
                a.status
            FROM applications a
            LEFT JOIN users u ON a.student_id = u.id
            LEFT JOIN internships i ON a.internship_id = i.id
            ORDER BY a.applied_at DESC
        `;

        db.query(query, (err, results) => {
            if (err) {
                console.error('Database query error:', err.message);
                return res.status(500).json({
                    message: 'Database error',
                    error: err.message
                });
            }
            res.json(results);
        });
    }
);

// ==========================================
// UPDATE APPLICATION STATUS & NOTIFY STUDENT
// ==========================================
router.put(
    '/applications/:id/status',
    verifyToken,
    checkRole(['employer', 'admin']),
    (req, res) => {
        const appId = req.params.id;
        const { status } = req.body;

        const allowedStatuses = [
            'Pending',
            'Submitted',
            'Shortlisted',
            'Interviewing',
            'Accepted',
            'Rejected'
        ];

        if (!allowedStatuses.includes(status)) {
            return res.status(400).json({
                message: 'Invalid application status'
            });
        }

        const query = `
            UPDATE applications
            SET status = ?
            WHERE id = ?
        `;

        db.query(query, [status, appId], (err, result) => {
            if (err) {
                console.error('Status update error:', err.message);
                return res.status(500).json({
                    message: 'Database error',
                    error: err.message
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    message: 'Application not found'
                });
            }

            const getAppQuery = `SELECT student_id FROM applications WHERE id = ?`;
            db.query(getAppQuery, [appId], (appErr, appResults) => {
                if (!appErr && appResults.length > 0) {
                    const studentId = appResults[0].student_id;
                    const notifTitle = 'Application Status Updated';
                    const notifMsg = `Your internship application status has been updated to: ${status}`;
                    
                    const notifQuery = `INSERT INTO notifications (user_id, title, message, created_at) VALUES (?, ?, ?, NOW())`;
                    db.query(notifQuery, [studentId, notifTitle, notifMsg], (notifErr) => {
                        if (notifErr) console.error('Error creating notification:', notifErr.message);
                    });
                }
            });

            res.json({
                message: 'Status updated successfully'
            });
        });
    }
);

module.exports = router;