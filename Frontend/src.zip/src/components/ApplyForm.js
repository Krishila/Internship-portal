import React, { useState } from 'react';
import axios from 'axios';
import './ApplyForm.css';

const ApplyForm = ({ internship, onCancel, onSuccess }) => {
  const token = localStorage.getItem('token');

  const [appData, setAppData] = useState({
    full_name: '',
    address: '',
    phone: '',
    education: '',
    gpa: '',
    skills: '',
    experience: '',
    resume_link: ''
  });

  const [previewUrl, setPreviewUrl] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setAppData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    const reader = new FileReader();

    reader.onloadend = () => {
      setAppData((prev) => ({
        ...prev,
        resume_link: reader.result
      }));

      setPreviewUrl(reader.result);
    };

    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!appData.resume_link) {
      alert('Please upload your Resume/CV.');
      return;
    }

    setSubmitting(true);

    try {
      const res = await axios.post(
        'http://localhost:5000/api/applications/apply',
        {
          internship_id: internship?.id,
          ...appData
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      alert(
        res.data.message ||
        'Application submitted successfully!'
      );

      onSuccess();

    } catch (err) {
      console.error('Application error:', err);

      alert(
        err.response?.data?.message ||
        'Failed to submit application.'
      );

    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="apply-card-container">

      <h2>
        Apply for {internship?.title || 'Internship'}
      </h2>

      <form
        onSubmit={handleSubmit}
        className="standard-apply-form"
      >

        {/* NAME */}
        <div className="form-group">
          <label>Full Name</label>

          <input
            type="text"
            name="full_name"
            placeholder="Full Name"
            value={appData.full_name}
            onChange={handleChange}
            required
          />
        </div>


        {/* ADDRESS */}
        <div className="form-group">
          <label>Address</label>

          <input
            type="text"
            name="address"
            placeholder="Address"
            value={appData.address}
            onChange={handleChange}
            required
          />
        </div>


        {/* PHONE */}
        <div className="form-group">
          <label>Phone</label>

          <input
            type="text"
            name="phone"
            placeholder="Phone Number"
            value={appData.phone}
            onChange={handleChange}
            required
          />
        </div>


        {/* EDUCATION */}
        <div className="form-group">
          <label>Education</label>

          <input
            type="text"
            name="education"
            placeholder="e.g. BSc CSIT, BIT, BCA"
            value={appData.education}
            onChange={handleChange}
            required
          />
        </div>


        {/* GPA */}
        <div className="form-group">
          <label>GPA</label>

          <input
            type="number"
            name="gpa"
            placeholder="e.g. 3.50"
            min="0"
            max="4"
            step="0.01"
            value={appData.gpa}
            onChange={handleChange}
            required
          />
        </div>


        {/* SKILLS */}
        <div className="form-group">
          <label>Skills</label>

          <textarea
            name="skills"
            placeholder="e.g. React, Node.js, MySQL, Java"
            value={appData.skills}
            onChange={handleChange}
            rows="3"
            required
          />
        </div>


        {/* EXPERIENCE */}
        <div className="form-group">
          <label>Experience</label>

          <textarea
            name="experience"
            placeholder="Describe your experience or write No experience"
            value={appData.experience}
            onChange={handleChange}
            rows="3"
            required
          />
        </div>


        {/* RESUME */}
        <div className="form-group">

          <label>
            Upload Resume/CV
          </label>

          <input
            type="file"
            accept="image/*,.pdf"
            onChange={handleFileChange}
            required
          />

          {previewUrl && (
            <div style={{ marginTop: '10px' }}>

              <small
                style={{
                  color: '#64748b',
                  display: 'block',
                  marginBottom: '4px'
                }}
              >
                Resume Preview:
              </small>

              {previewUrl.startsWith('data:image') ? (
                <img
                  src={previewUrl}
                  alt="Resume Preview"
                  style={{
                    maxWidth: '100%',
                    maxHeight: '180px',
                    borderRadius: '6px',
                    border: '1px solid #cbd5e1'
                  }}
                />
              ) : (
                <p>
                  Resume uploaded successfully.
                </p>
              )}

            </div>
          )}

        </div>


        {/* BUTTONS */}
        <div className="form-actions">

          <button
            type="submit"
            className="btn-primary-submit"
            disabled={submitting}
          >
            {submitting
              ? 'Submitting...'
              : 'Submit Application'}
          </button>

          <button
            type="button"
            className="btn-secondary-cancel"
            onClick={onCancel}
          >
            Cancel
          </button>

        </div>

      </form>
    </div>
  );
};

export default ApplyForm;