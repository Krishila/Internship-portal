import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function EmployerDashboard() {
    const [applications, setApplications] = useState([]);
    const [errorMsg, setErrorMsg] = useState('');

    const fetchApplications = () => {
        const token = localStorage.getItem('token');
        axios.get('http://localhost:5000/api/employer/applications', {
            headers: { Authorization: `Bearer ${token}` }
        })
            .then(res => setApplications(res.data))
            .catch(err => {
                console.error("API error response:", err.response?.data || err.message);
                setErrorMsg(err.response?.data?.message || err.message);
            });
    };

    useEffect(() => {
        fetchApplications();
    }, []);

    const handleStatusChange = (appId, newStatus) => {
        const token = localStorage.getItem('token');
        
        axios.put(`http://localhost:5000/api/employer/applications/${appId}/status`, { status: newStatus }, {
            headers: { Authorization: `Bearer ${token}` }
        })
            .then(() => {
                setApplications(applications.map(app => 
                    (app.id === appId || app.app_id === appId) ? { ...app, status: newStatus } : app
                ));
            })
            .catch(err => {
                console.error("Failed to update status:", err.response?.data || err);
                alert(`Failed to update status: ${err.response?.data?.message || err.message}`);
            });
    };

    const handleViewResume = (resumeData) => {
        if (!resumeData) return;

        if (resumeData.startsWith('data:')) {
            try {
                const arr = resumeData.split(',');
                const mimeMatch = arr[0].match(/:(.*?);/);
                const mime = mimeMatch ? mimeMatch[1] : 'image/png';
                const bstr = atob(arr[1]);
                let n = bstr.length;
                const u8arr = new Uint8Array(n);
                while (n--) {
                    u8arr[n] = bstr.charCodeAt(n);
                }
                const blob = new Blob([u8arr], { type: mime });
                const blobUrl = URL.createObjectURL(blob);
                window.open(blobUrl, '_blank');
            } catch (e) {
                console.error("Error opening base64 resume:", e);
                // Fallback attempt
                window.open(resumeData, '_blank');
            }
        } else {
            const url = resumeData.startsWith('http') 
                ? resumeData 
                : `http://localhost:5000/uploads/${resumeData}`;
            window.open(url, '_blank');
        }
    };

    return (
        <div className="container mt-4">
            <h2>Employer Dashboard - Manage Applicants</h2>
            {errorMsg && <div className="alert alert-danger">Error: {errorMsg}</div>}
            <table className="table table-striped mt-3">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Candidate Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Internship</th>
                        <th>Applied Date</th>
                        <th>Resume / CV</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {applications.length > 0 ? (
                        applications.map((app, index) => {
                            const uniqueId = app.app_id || app.id;
                            return (
                                <tr key={uniqueId || index}>
                                    <td>{index + 1}</td>
                                    <td>{app.student_name || app.full_name || app.name || 'N/A'}</td>
                                    <td>{app.student_email || app.email || 'N/A'}</td>
                                    <td>{app.student_phone || app.phone || 'N/A'}</td>
                                    <td>{app.internship_title || app.title || 'N/A'}</td>
                                    <td>
                                        {app.applied_date || app.applied_at 
                                            ? new Date(app.applied_date || app.applied_at).toLocaleDateString() 
                                            : 'N/A'}
                                    </td>
                                    <td>
                                        {app.student_resume ? (
                                            <button 
                                                onClick={() => handleViewResume(app.student_resume)}
                                                className="btn btn-link p-0"
                                                style={{ color: 'blue', textDecoration: 'underline', background: 'none', border: 'none' }}
                                            >
                                                View CV
                                            </button>
                                        ) : (
                                            'No CV'
                                        )}
                                    </td>
                                    <td>
                                        <span className="badge bg-info text-dark">{app.status}</span>
                                    </td>
                                    <td>
                                        <select 
                                            value={app.status} 
                                            onChange={(e) => handleStatusChange(uniqueId, e.target.value)}
                                            className="form-select form-select-sm"
                                        >
                                            <option value="Pending">Pending</option>
                                            <option value="Submitted">Submitted</option>
                                            <option value="Accepted">Accepted</option>
                                            <option value="Rejected">Rejected</option>
                                        </select>
                                    </td>
                                </tr>
                            );
                        })
                    ) : (
                        <tr>
                            <td colSpan="9" className="text-center text-muted">No applications found.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    );
}