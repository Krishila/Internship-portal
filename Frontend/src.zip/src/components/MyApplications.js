import React, { useEffect, useState } from "react";
import "./MyApplications.css";

function MyApplications() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");

    fetch("http://localhost:5000/api/applications/my-applications", {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to load applications");
        }
        return res.json();
      })
      .then((data) => {
        setApplications(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Application loading error:", err);
        setLoading(false);
      });
  }, []);

  // Check whether a status has been reached
  const isStatusReached = (currentStatus, status) => {
    const statusOrder = [
      "Submitted",
      "Accepted"
    ];

    if (currentStatus === "Rejected") {
      return false;
    }

    return (
      statusOrder.indexOf(currentStatus) >=
      statusOrder.indexOf(status)
    );
  };

  if (loading) {
    return (
      <div className="text-center py-5">
        <h5>Loading applications...</h5>
      </div>
    );
  }

  return (
    <div className="container py-4 applications-page">
      <h2 className="fw-bold mb-4">
        My Applications
      </h2>

      {applications.length === 0 ? (
        <div className="empty-applications text-center p-5">
          <h4>No Applications Yet</h4>
          <p className="text-muted">
            You have not applied for any internship yet.
          </p>
        </div>
      ) : (
        applications.map((app) => (
          <div
            className="application-card shadow-sm rounded-4 p-4 mb-4 bg-white"
            key={app.id}
          >
            {/* Application Header */}
            <div className="application-header d-flex justify-content-between align-items-center">
              <div>
                <h4 className="fw-bold">
                  {app.internship_title}
                </h4>

                <p className="text-muted mb-1">
                  <strong>Company:</strong>{" "}
                  {app.company_name}
                </p>

                <p className="text-muted mb-1">
                  <strong>Location:</strong>{" "}
                  {app.location || "Not specified"}
                </p>

                <p className="text-muted">
                  <strong>Applied Date:</strong>{" "}
                  {new Date(
                    app.applied_date
                  ).toLocaleDateString()}
                </p>
              </div>

              {/* Current Status */}
              <span
                className={`status badge fs-6 px-3 py-2 ${app.status
                  .toLowerCase()
                  .replace(" ", "-")}`}
              >
                {app.status}
              </span>
            </div>

            <hr />

            {/* Rejected Application */}
            {app.status === "Rejected" ? (
              <div className="rejected-box mt-4 p-4 rounded-3">
                <div className="rejected-icon">
                  ✕
                </div>
                <div>
                  <h5 className="fw-bold text-danger">
                    Application Rejected
                  </h5>
                  <p className="mb-0 text-muted">
                    Unfortunately, your application was
                    not selected for this internship.
                  </p>
                </div>
              </div>
            ) : (
              /* Normal Status Pipeline */
              <div className="status-pipeline">
                {[
                  "Submitted",
                  "Rejected",
                  "Accepted"
                ].map((status, index) => (
                  <React.Fragment key={status}>
                    <div
                      className={
                        isStatusReached(
                          app.status,
                          status
                        )
                          ? "step active"
                          : "step"
                      }
                    >
                      <div className="circle">
                        {isStatusReached(
                          app.status,
                          status
                        )
                          ? "✓"
                          : index + 1}
                      </div>
                      <span>
                        {status}
                      </span>
                    </div>

                    {index < 3 && (
                      <div
                        className={
                          isStatusReached(
                            app.status,
                            [
                           
                            ][index]
                          )
                            ? "line active-line"
                            : "line"
                        }
                      />
                    )}
                  </React.Fragment>
                ))}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
}

export default MyApplications;