import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Notifications() {
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchNotifications = () => {
        const token = localStorage.getItem('token');
        axios.get('http://localhost:5000/api/user/notifications', {
            headers: { Authorization: `Bearer ${token}` }
        })
            .then(res => {
                setNotifications(res.data);
                setLoading(false);
            })
            .catch(err => {
                console.error("Failed to load notifications:", err);
                setLoading(false);
            });
    };

    useEffect(() => {
        
        fetchNotifications();

      
        const interval = setInterval(() => {
            fetchNotifications();
        }, 5000);

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="container mt-4">
            <h2>Your Notifications</h2>
            {loading ? (
                <p>Loading notifications...</p>
            ) : notifications.length > 0 ? (
                <div className="list-group mt-3">
                    {notifications.map((n, index) => (
                        <div key={n.id || index} className="list-group-item list-group-item-action flex-column align-items-start mb-2">
                            <div className="d-flex w-100 justify-content-between">
                                <h5 className="mb-1">{n.title || 'System Notification'}</h5>
                                <small>{n.created_at ? new Date(n.created_at).toLocaleDateString() : ''}</small>
                            </div>
                            <p className="mb-1">{n.message}</p>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="alert alert-info mt-3">No notifications found regarding job posts, verifications, or status updates.</div>
            )}
        </div>
    );
}