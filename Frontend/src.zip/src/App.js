import React, { useState } from 'react';

import Login from './components/Login';
import Register from './components/Register';
import Internships from './components/Internships';
import MyApplications from './components/MyApplications';
import ApplyForm from './components/ApplyForm';
import AdminPanel from './components/AdminVerification';
import EmployerDashboard from './components/EmployerDashboard';
import Notifications from './components/Notifications';

import AdminUsers from './components/AdminUsers';
import AdminEmployers from './components/AdminEmployers';

function AdminApplications() { 
  return <div className="container py-4"><h2 className="fw-bold">All Applications Page</h2><p className="text-muted">Overview of student internship applications.</p></div>; 
}

function App() {

  // ==========================================
  // GET STORED USER & TOKEN VALIDATION
  // ==========================================

  const getStoredUser = () => {
    try {
      const token = localStorage.getItem('token');
      const user = JSON.parse(localStorage.getItem('user') || 'null');
      
      // If either token or user is missing, clear both and force login
      if (!token || !user) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        return null;
      }
      return user;
    } catch {
      return null;
    }
  };

  const storedToken = localStorage.getItem('token');
  const storedUser = getStoredUser();

  // ==========================================
  // LOGIN STATE
  // ==========================================

  const [isLoggedIn, setIsLoggedIn] = useState(
    !!storedToken && !!storedUser
  );

  const [currentUser, setCurrentUser] = useState(storedUser);

  // ==========================================
  // INITIAL VIEW
  // ==========================================

  const [view, setView] = useState(() => {
    if (!storedToken || !storedUser) {
      return 'login';
    }

    const role = (storedUser.role || '').toLowerCase();

    if (role === 'student') return 'internships';
    if (role === 'employer') return 'employer-dashboard';
    if (role === 'admin') return 'admin'; 

    return 'login';
  });

  const [selectedInternship, setSelectedInternship] = useState(null);

  const role = (currentUser?.role || '').toLowerCase();

  const isStudent = role === 'student';
  const isEmployer = role === 'employer';
  const isAdmin = role === 'admin';

  const handleLoginSuccess = (loggedInUser) => {
    const user = loggedInUser || JSON.parse(localStorage.getItem('user') || 'null');
    
    if (!user) {
      alert('User data missing.');
      return;
    }

    setCurrentUser(user);
    setIsLoggedIn(true);

    const userRole = (user.role || '').toLowerCase();

    if (userRole === 'student') {
      setView('internships');
    } else if (userRole === 'employer') {
      setView('employer-dashboard');
    } else if (userRole === 'admin') {
      setView('admin');
    } else {
      alert('Invalid user role.');
      handleLogout();
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');

    setCurrentUser(null);
    setIsLoggedIn(false);
    setView('login');
    setSelectedInternship(null);
  };

  const handleRegisterSuccess = () => {
    setView('login');
  };

  const handleApplyClick = (internship) => {
    setSelectedInternship(internship);
    setView('apply');
  };

  return (
    <div className="App">
      {/* ================= DYNAMIC NAVBAR ================= */}
      {isLoggedIn && (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark mb-4 px-4 shadow-sm">
          <div className="container-fluid">
            <span className="navbar-brand fw-bold">
              Internship Portal {isAdmin && <span className="badge bg-danger ms-2 font-monospace">Admin</span>}
            </span>
            <div className="collapse navbar-collapse justify-content-end">
              <div className="navbar-nav align-items-center">
                {/* STUDENT NAVBAR */}
                {isStudent && (
                  <>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('internships')}>
                      Home
                    </button>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('internships')}>
                      Internships
                    </button>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('applications')}>
                      My Applications
                    </button>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('notifications')}>
                      Notifications
                    </button>
                  </>
                )}

                {/* EMPLOYER NAVBAR */}
                {isEmployer && (
                  <>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('employer-dashboard')}>
                      Dashboard
                    </button>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('internships')}>
                      Internships
                    </button>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('employer-dashboard')}>
                      Applicants
                    </button>
                  </>
                )}

                {/* ADMIN NAVBAR */}
                {isAdmin && (
                  <>
                    <button className="btn btn-link text-light text-decoration-none me-2" onClick={() => setView('admin')}>
                      Dashboard
                    </button>
                  </>
                )}

                <button
                  className="btn btn-danger btn-sm ms-3 px-3"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </nav>
      )}

      {/* ================= MAIN CONTENT VIEW ROUTING ================= */}
      <div className="container">
        {!isLoggedIn ? (
          view === 'register' ? (
            <Register
              onRegisterSuccess={handleRegisterSuccess}
              onSwitchToLogin={() => setView('login')}
            />
          ) : (
            <Login
              onLoginSuccess={handleLoginSuccess}
              onSwitchToRegister={() => setView('register')}
            />
          )
        ) : (
          <>
            {view === 'internships' && (isStudent || isEmployer) && (
              <Internships onApplyClick={handleApplyClick} />
            )}

            {view === 'applications' && isStudent && (
              <MyApplications />
            )}

            {view === 'notifications' && isStudent && (
              <Notifications />
            )}

            {view === 'apply' && isStudent && (
              <ApplyForm
                internship={selectedInternship}
                onCancel={() => setView('internships')}
                onSuccess={() => setView('applications')}
              />
            )}

            {view === 'employer-dashboard' && isEmployer && (
              <EmployerDashboard />
            )}

            {/* Admin Views */}
            {view === 'admin' && isAdmin && (
              <AdminPanel />
            )}
            {view === 'admin-users' && isAdmin && (
              <AdminUsers />
            )}
            {view === 'admin-employers' && isAdmin && (
              <AdminEmployers />
            )}
            {view === 'admin-applications' && isAdmin && (
              <AdminApplications />
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default App;